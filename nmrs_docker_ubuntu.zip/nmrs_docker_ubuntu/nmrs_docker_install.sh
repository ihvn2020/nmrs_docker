#!/bin/bash
# Thur 27 Feb 2025 11:45:56 

# **************************************************************************************** #
# ***********************CTRL --Ubuntu_24.04 --IHVN*************************** #
# **************************************************************************************** #
echo '     '
echo '---------------------------------------------------------------     '
echo '  INSTITUTE      OF       HUMAN       VIROLOGY,      NIGERIA        '
echo '---------------------------------------------------------------     '
echo '                                                                    '
echo '  *********   ***       ***    ****     ****     ***      ***       '
echo '  *********   ***       ***    ****     ****     ****     ***       '
echo '     ***      ***       ***    ****     ****     *****    ***       '
echo '     ***      ***       ***    ****     ****     ******   ***       '
echo '     ***      *************    ****     ****     *** ***  ***       '
echo '     ***      *************    ****    *****     ***  *******       '
echo '     ***      ***       ***     ***** *****      ***   ******       '
echo '     ***      ***       ***      *********       ***    *****       '
echo '  *********   ***       ***       *******        ***     ****       '
echo '  *********   ***       ***         ****         ***      ***       '
echo '     '
echo '---------------------------------------------------------------     '
echo '  #NMRS installation using Docker          #IHVN,2025   '
echo '---------------------------------------------------------------     '
echo '     '
echo ' This program will install Docker CLI and dependencies and run a set of Apache Tomcat and MySQL...'
echo ' # ********************************************************************************* #'

sudo apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys B7B3B788A8D3785C 
sudo apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys EF9DBDC73B7D1A07

sudo apt-get update


# ==========================mysql-workbench===================================== #
echo ' # ***************Installing mysql-workbench************************************* #'

sudo snap install mysql-workbench-community

sudo chmod 644 my.cnf

echo ' Installing Docker...'
sudo apt update
echo ' Updating system...'

echo ' Installing prerequisites...'
sudo apt install -y ca-certificates curl gnupg

echo ' Add Docker’s official GPG key...'
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

echo 'Set up the Docker apt repository...'
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  noble stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

echo ' Update package list'
sudo apt update

echo ' Install Docker Engine + CLI + containerd'
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

echo ' Starting Docker Compose services...'
sudo docker compose up -d

echo ""
echo "Docker installation is now complete and your containers are running."
echo "Consider importing your database and follow the installation guide"
echo "to deploy NMRS and connect it to the database."
echo ""
echo "This message will close in 30 seconds..."
sleep 30

exit 0
